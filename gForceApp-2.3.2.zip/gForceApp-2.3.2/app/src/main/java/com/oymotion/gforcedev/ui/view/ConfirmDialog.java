package com.oymotion.gforcedev.ui.view;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.oymotion.gforcedev.R;

/**
 * 作者： huao onShowError 2016/7/21.
 * 说明：
 */
public class ConfirmDialog extends DialogFragment {
    private String title;
    private String confirmButtonText;
    private String cancelButtonText;
    private ClickListenerInterface clickListenerInterface;
    private String msg;


    public static ConfirmDialog getDialog(String title, String msg, String confirmButtonText, String cancelButtonText){
        ConfirmDialog dialog = new ConfirmDialog();
        Bundle bundle = new Bundle();
        bundle.putString("title",title);
        if (msg != null) bundle.putString("msg",msg);
        if (confirmButtonText == null) confirmButtonText = "确认";
        if (cancelButtonText == null) cancelButtonText = "取消";
        bundle.putString("confirm",confirmButtonText);
        bundle.putString("cancel",cancelButtonText);
        dialog.setArguments(bundle);
        return dialog;
    }

    public interface ClickListenerInterface {
        void confirm();
        void cancel();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (savedInstanceState == null){
            this.title = getArguments().getString("title");
            this.confirmButtonText = getArguments().getString("confirm");
            this.cancelButtonText = getArguments().getString("cancel");
            this.msg = getArguments().getString("msg");
        }else{
            this.title = savedInstanceState.getString("title");
            this.confirmButtonText = savedInstanceState.getString("confirm");
            this.cancelButtonText = savedInstanceState.getString("cancel");
            this.msg = savedInstanceState.getString("msg");
        }
        View view = inflater.inflate(R.layout.dialog_confirm, container);
        initView(view);
        return view;
    }
    @Override
    public void onStart() {
        super.onStart();
        DisplayMetrics dm = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics( dm );
        getDialog().getWindow().setLayout((int) (dm.widthPixels * 0.8), getDialog().getWindow().getAttributes().height );
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("title",title);
        outState.putString("confirm",confirmButtonText);
        outState.putString("cancel",cancelButtonText);
        if (msg != null)outState.putString("msg",msg);
    }

    private void initView(View view) {
        TextView tvTitle = (TextView) view.findViewById(R.id.dialog_title);
        TextView tvConfirm = (TextView) view.findViewById(R.id.confirm);
        TextView tvCancel = (TextView) view.findViewById(R.id.cancel);
        TextView tvMessage = (TextView) view.findViewById(R.id.dialog_recommend);
        TextPaint tp = tvTitle.getPaint();
        tp.setFakeBoldText(true);
        tvTitle.setText(title);
        if (msg == null){
            tvMessage.setVisibility(View.GONE);
        }else{
            tvMessage.setText(msg);
        }
        tvConfirm.setText(confirmButtonText);
        tvCancel.setText(cancelButtonText);

        tvConfirm.setOnClickListener(new OnConfirmClickListener());
        tvCancel.setOnClickListener(new OnConfirmClickListener());

    }

    public void setClicklistener(ClickListenerInterface clickListenerInterface) {
        this.clickListenerInterface = clickListenerInterface;
    }

    private class OnConfirmClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.confirm:
                    clickListenerInterface.confirm();
                    dismiss();
                    break;
                case R.id.cancel:
                    dismiss();
                    clickListenerInterface.cancel();
                    break;
            }
        }
    }
}
