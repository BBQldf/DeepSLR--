package com.oymotion.gforcedev.gforce_control;

/**
 * Created by Zhou Yu (local) on 2016/11/18.
 */

public class Quaternion {
    public float w;
    public float x;
    public float y;
    public float z;

    public Quaternion(float w, float x, float y, float z) {
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}