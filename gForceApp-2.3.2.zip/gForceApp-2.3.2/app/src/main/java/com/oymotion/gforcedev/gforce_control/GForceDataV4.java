package com.oymotion.gforcedev.gforce_control;

import android.util.Log;
import android.util.SparseArray;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/** gForce data V4 parsing.
 *  Created by Ethan on 2017/8/31 0030.
 */
public class GForceDataV4 {
    private final static String TAG = GForceDataV4.class.getSimpleName();

    // Types of data
    public static final int QUATERNION_FLOAT      = 0x05;
    public static final int GESTURE               = 0x07;
    public static final int STATUS_UPDATE         = 0x0B;

    // Types of gesture data
    public static final int GESTURE_RELAX                  = 0x0;
    public static final int GESTURE_GIST                   = 0x1;
    public static final int GESTURE_SPREAD_FINGERS         = 0x2;
    public static final int GESTURE_WAVE_TOWARD_PALM       = 0x3;
    public static final int GESTURE_WAVE_BACKWARD_PALM     = 0x4;
    public static final int GESTURE_TUCK_FINGERS           = 0x5;
    public static final int GESTURE_SHOOT                  = 0x6;
    public static final int GESTURE_MAX                    = GESTURE_SHOOT;
    public static final int GESTURE_UNKNOWN                = -1;

    private static final SparseArray<String> mGestureNames = new SparseArray<String>();

    static {
        mGestureNames.put(GESTURE_RELAX, "GESTURE_RELAX");
        mGestureNames.put(GESTURE_GIST, "GESTURE_GIST");
        mGestureNames.put(GESTURE_SPREAD_FINGERS, "GESTURE_SPREAD_FINGERS");
        mGestureNames.put(GESTURE_WAVE_TOWARD_PALM, "GESTURE_WAVE_TOWARD_PALM");
        mGestureNames.put(GESTURE_WAVE_BACKWARD_PALM,  "GESTURE_WAVE_BACKWARD_PALM");
        mGestureNames.put(GESTURE_TUCK_FINGERS, "GESTURE_TUCK_FINGERS");
        mGestureNames.put(GESTURE_SHOOT,  "GESTURE_SHOOT");
        mGestureNames.put(GESTURE_UNKNOWN,  "GESTURE_UNKNOWN");
    }

    // For Status update
    // Pose base coordinate frame was synchronized, meaning that, the next
    // quaternion [w, x, y, z] will be [1, 0, 0, 0]
    public static final int STATUS_UPDATE_BASE_COORD_FRAME_SYNCHRONIZED = 1;

    // internal data members
    private int mType;
    private Byte mPackageNum;             // 0-255, for check continuity of packages
    private Quaternion mQuaternion;
    private int mGesture;
    private int mStatus;

    private GForceDataV4(int type, Quaternion quaternion, Byte package_num) {
        mType = type;
        mQuaternion = quaternion;
        mPackageNum = package_num;
    }

    private GForceDataV4(int type, int i, Byte package_num) {
        mType = type;
        if (type == GESTURE) {
            mGesture = i;
        }
        else if (type == STATUS_UPDATE) {
            mStatus = i;
        }

        mPackageNum = package_num;
    }

    public static class Builder {
        private byte[] mData;

        public Builder(byte[] data) {
            mData = data;
        }

        public GForceDataV4 build() {
            // bytes[0][0:6] - type
            // bytes[1:] - data
            //      if (bytes[0][7] == 1)
            //          bytes[1] - Package Number for checking integrity of packages sequence.
            int type = (int)(mData[0] & 0x7F);
            int package_id_shift = (mData[0] & 0x80) == 0x80 ? 1 : 0;
            Byte package_num = null;
            if (package_id_shift == 1) {
                package_num = mData[1];
            }
            int payload_start_index = 1 + package_id_shift;

            if (type == QUATERNION_FLOAT) {
                if (mData.length < package_id_shift + 16) {
                     return null;
                }
                float[] q = new float[4];

                for (int i = 0; i < 4; i++) {
                    int copy_index = payload_start_index + i * 4;
                    byte[] bytes = Arrays.copyOfRange(mData,  copy_index , copy_index + 4);
                    q[i] = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getFloat();
                }

                Quaternion quat = new Quaternion(q[0], q[1], q[2], q[3]);

                return new GForceDataV4(type, quat, package_num);
            }
            else if (type == GESTURE) {
                if (mData.length < package_id_shift + 1) {
                    return null;
                }
                int gesture = (int)mData[payload_start_index];
                if (gesture > GESTURE_MAX && gesture != GESTURE_UNKNOWN) {
                    Log.e(TAG, String.format("Illegal gesture value: %d", gesture));
                    return null;
                }
                else {
                    return new GForceDataV4(type, gesture, package_num);
                }
            }
            else if (type == STATUS_UPDATE) {
                if (mData.length < package_id_shift + 1) {
                    return null;
                }
                int status = (int)mData[payload_start_index];
                return new GForceDataV4(type, status, package_num);
            }

            return null;
        }
    }

    public int getType() {
        return mType;
    }

    public Byte getPackageId() {
        return mPackageNum;
    }

    public Quaternion getQuaternion() {
        return mQuaternion;
    }

    public int getGesture() {
        return mGesture;
    }

    public String getGestureName(){
        return mGestureNames.get(mGesture);
    }

    public static String getGestureName(int gesture){
        return mGestureNames.get(gesture);
    }

    public int getStatusUpdate() {
        return mStatus;
    }
}
