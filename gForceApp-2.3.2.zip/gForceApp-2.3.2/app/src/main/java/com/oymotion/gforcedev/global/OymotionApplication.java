package com.oymotion.gforcedev.global;

import android.app.Application;

/***
 * OymotionApplication
 * @author MouMou
 *
 */

public class OymotionApplication extends Application {
    public static OymotionApplication context;
    public static String deviceName = "temp";
    public static String deviceAddress = "temp";
    public static String versionAddress;
    public static boolean oadProgress = false;

    @Override
    public void onCreate() {
        context = this;
        super.onCreate();
    }
}
