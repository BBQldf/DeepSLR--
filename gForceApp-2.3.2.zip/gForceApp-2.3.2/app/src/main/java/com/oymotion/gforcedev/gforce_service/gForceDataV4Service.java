package com.oymotion.gforcedev.gforce_service;

import java.util.HashMap;

/** gForce data and gForce control service.
 *  Created by Ethan on 2017/8/30 0030.
 */
public class gForceDataV4Service extends gForceService {
    private final static String TAG = gForceDataV4Service.class.getSimpleName();

    protected gForceDataV4Service() {
    }

    public static final String UUID_SERVICE = "f000ffd0-0451-4000-b000-000000000000";

    public static final String UUID_CTRL_CMD = "f000ffe1-0451-4000-b000-000000000000";

    public static final String UUID_DATA_NOTI = "f000ffe2-0451-4000-b000-000000000000";

    private static final HashMap<String, String> CHARACTERISTIC_MAP = new HashMap<String, String>();
    private static HashMap<String, String> CHARACTERISTIC_VAL_MAP = new HashMap<String, String>();

    static {
        CHARACTERISTIC_MAP.put(UUID_CTRL_CMD, "gForce Control Command");
        CHARACTERISTIC_MAP.put(UUID_DATA_NOTI, "gForce Data Notify");
    }

    static {
        CHARACTERISTIC_VAL_MAP.put(UUID_CTRL_CMD, "Click switch to OAD mode");
        CHARACTERISTIC_VAL_MAP.put(UUID_DATA_NOTI, "Start data notify");
    }

    @Override
    public String getUUID() {
        return UUID_SERVICE;
    }

    @Override
    public String getName() {
        return "gForce Data V4";
    }

    @Override
    public String getCharacteristicName(String uuid) {
        if (!CHARACTERISTIC_MAP.containsKey(uuid)) {
            return "Unknown";
        }
        return CHARACTERISTIC_MAP.get(uuid);
    }

    @Override
    public String getCharacteristicValue(String uuid) {
        if (!CHARACTERISTIC_VAL_MAP.containsKey(uuid))
            return null;
        return CHARACTERISTIC_VAL_MAP.get(uuid);
    }

    @Override
    public void setCharacteristicValue(String uuid, String valueStr) {
        if (CHARACTERISTIC_VAL_MAP.containsKey(uuid))
            CHARACTERISTIC_VAL_MAP.put(uuid, valueStr);
    }
}
