# ChangeLog
Versioning follows the Sematic Versioning 2.0.0 rule.

## v2.3.0
1. AD upgrade completed notice
2. Gesture model load easier
3. Hardware/Firmware version display

## initial release
1. Supports gForce firmware R3
2. HTML5 based GUI
3. Supports OAD firmware upgrade
